<template>
  <div>
    <ul class="nav justify-content-center">
      <li class="nav-item">
        <RouterLink :to="{ name: 'DoWalk' }" style="text-decoration-line: none">
          <a class="nav-link" aria-current="page" href="#">산책하기</a>
        </RouterLink>
      </li>
      <li class="nav-item">
        <RouterLink :to="{ name: 'WalkList' }" style="text-decoration-line: none">
          <a class="nav-link" href="#">내코스</a>
        </RouterLink>
      </li>
      <li class="nav-item">
        <RouterLink :to="{ name: 'RecordScrapList' }" style="text-decoration-line: none">
          <a class="nav-link" href="#">스크랩한 코스</a>
        </RouterLink>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">산책 경로추천</a>
      </li>
    </ul>
  </div>
</template>

<script setup></script>

<style scoped></style>
