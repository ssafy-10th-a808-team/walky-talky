<template>
  <!-- ======= Header ======= -->
  <header id="header" class="d-flex align-items-center">
    <div class="container d-flex align-items-center">
      <h1 class="logo me-auto"><RouterLink :to="{ name: 'home' }">Walky Talky</RouterLink></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar">
        <ul>
          <li>
            <RouterLink :to="{ name: 'club' }" class="nav-link scrollto active"
              >소모임찾기</RouterLink
            >
          </li>
          <li>
            <RouterLink :to="{ name: 'DoWalk' }" class="nav-link scrollto">산책하기</RouterLink>
          </li>
          <li><a class="nav-link scrollto" href="#services">산책공유</a></li>
          <!-- <li><a class="nav-link scrollto" href="#portfolio">Portfolio</a></li>
          <li><a class="nav-link scrollto" href="#team">Team</a></li> -->
          <li class="dropdown"  v-if="memberstore.isLogin"><a href="#"><span>{{ memberstore.nickname }}</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="#">마이페이지</a></li>
              <!-- <li class="dropdown"><a href="#"><span>Deep Drop Down</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="#">Deep Drop Down 1</a></li>
                  <li><a href="#">Deep Drop Down 2</a></li>
                  <li><a href="#">Deep Drop Down 3</a></li>
                  <li><a href="#">Deep Drop Down 4</a></li>
                  <li><a href="#">Deep Drop Down 5</a></li>
                </ul>
              </li> -->
              <li><RouterLink :to="{ name: 'Logout'}"><a href="#">로그아웃</a></RouterLink></li>
              <!-- <li><a href="#">Drop Down 3</a></li>
              <li><a href="#">Drop Down 4</a></li> -->
            </ul>
          </li>
          <!-- <li><a class="nav-link scrollto" href="#contact">Contact</a></li> -->
          <li v-if="!memberstore.isLogin">
            <RouterLink :to="{ name: 'Login' }" class="getstarted scrollto">로그인</RouterLink>
          </li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>
      <!-- .navbar -->
    </div>
  </header>
  <!-- End Header -->
</template>

<script setup>
import { useMemberStore } from '@/stores/member';
const memberstore = useMemberStore()






</script>

<style scoped></style>
