<template>
    <div>
        <p>좋아요 개수 {{ likeCount }}</p>
        <p>Liked: {{ liked ? 'Yes' : 'No' }}</p>
    </div>
</template>

<script setup>
    const { likeCount, liked } = defineProps(['likeCount', 'liked']);
</script>
