<template>
  <div>
    <p>{{ nickname }}</p>
    <image src="${profilePic}" />
    <p>{{ address }}</p>
    <p>{{ create_at }}</p>
    <p>{{ hit }}</p>
  </div>
</template>

<script setup>
const { nickname, profilePic, create_at, address, hit } = defineProps([
  'nickname',
  'url',
  'create_at',
  'address',
  'hit'
])
</script>
