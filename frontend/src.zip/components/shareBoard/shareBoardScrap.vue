<template>
  <div>
    <p>스크랩 개수 {{ scrapCount }}</p>
    <p>scraped: {{ scraped ? 'Yes' : 'No' }}</p>
  </div>
</template>

<script setup>
const { scrapCount, scraped } = defineProps(['scrapCount', 'scraped'])
</script>
