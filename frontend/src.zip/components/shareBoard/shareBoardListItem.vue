<template>
  <div>
    <div>
      <h4>member</h4>
      <shareBoardMember
        :nickname="content.member.nickname"
        :url="content.member.profilePic"
        :create_at="content.create_at"
        :address="record.address"
        :hit="content.hit"
      />
    </div>

    <div>
      <h4>title</h4>
      <shareBoardTitle :title="content.title" :commentCount="content.commentCount" />
      <h4>record</h4>
      <shareBoardRecord
        :duration="record.duration"
        :distance="record.distance"
        :points="record.points"
      />
      <h4>like</h4>
      <shareBoardLike :likeCount="like.likeCount" :liked="like.liked" />
      <h4>scrap</h4>
      <shareBoardScrap :scrapCount="scrap.scrapCount" :scraped="scrap.scraped" />
    </div>
  </div>
</template>

<script setup>
import shareBoardMember from '@/components/shareBoard/shareBoardMember.vue'
import shareBoardTitle from '@/components/shareBoard/shareBoardTitle.vue'
import shareBoardLike from '@/components/shareBoard/shareBoardLike.vue'
import shareBoardScrap from '@/components/shareBoard/shareBoardScrap.vue'
import shareBoardRecord from '@/components/shareBoard/shareBoardRecord.vue'

const { content, record, like, scrap } = defineProps({
  content: Object,
  record: Object,
  like: Object,
  scrap: Object
})
</script>
