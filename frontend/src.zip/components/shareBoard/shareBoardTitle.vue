<template>
  <div>
    <p>{{ title }}</p>
    <p>{{ commentCount }}</p>
  </div>
</template>

<script setup>
const { title, commentCount } = defineProps(['title', 'commentCount'])
</script>
