<template>
  <div>
    <div id="map" style="width: 600px; height: 400px" />
    <p>{{ distance }} km</p>
    <p>{{ duration }}</p>
  </div>
</template>

<script setup>
const { distance, duration, points } = defineProps(['distance', 'duration', 'points'])

const apiKey = import.meta.env.VITE_KAKAO_API_KEY

// 경로 폴리라인
var polyline = new kakao.maps.Polyline({
  map: map,
  path: points.map((point) => new kakao.maps.LatLng(point.latitude, point.longitude)),
  strokeWeight: 2,
  strokeColor: '#FF00FF',
  strokeOpacity: 0.8,
  strokeStyle: 'dashed'
})

var staticMapContainer = document.getElementById('map'), // 이미지 지도를 표시할 div
  staticMapOption = {
    center: new kakao.maps.LatLng(33.450701, 126.570667), // 이미지 지도의 중심좌표
    level: 3 // 이미지 지도의 확대 레벨
  }

// 이미지 지도를 표시할 div와 옵션으로 이미지 지도를 생성합니다
var staticMap = new kakao.maps.StaticMap(staticMapContainer, staticMapOption)
</script>
