<template>
  <div>
    <WalkHeaderNav />
    <h1>산책 스크랩 목록</h1>
  </div>
</template>

<script setup>
import WalkHeaderNav from '@/components/common/WalkHeaderNav.vue'
</script>

<style scoped></style>
