<template>
  <div>
    <WalkHeaderNav />
    <h1>내코스</h1>
  </div>
</template>

<script setup>
import WalkHeaderNav from '@/components/common/WalkHeaderNav.vue'
</script>

<style scoped></style>
